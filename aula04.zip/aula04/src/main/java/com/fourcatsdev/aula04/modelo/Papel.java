package com.fourcatsdev.aula04.modelo;

import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Papel {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Id;

	private String papel;

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public String getPapel() {
		return papel;
	}

	public void setPapel(String papel) {
		this.papel = papel;
	}
	
	@ManyToMany(mappedBy = "papeis", fetch = FetchType.EAGER)
	private Collection<Usuario> usuarios;

	
	
	public Papel() {
	}

	public Papel(String papel) {
		this.papel = papel;
	}


	}
